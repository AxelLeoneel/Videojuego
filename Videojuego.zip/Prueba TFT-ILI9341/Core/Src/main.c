/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdint.h>
#include "ili9341.h"
#include "bitmaps.h"
#include <math.h>
#include "pitches.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// Dimensiones aproximadas para cajas
#define PLAYER_W		34
#define PLAYER2_W		34
#define ENEMY_W			37
#define PLAYER_Y		123
#define PLAYER2_Y		123
#define ENEMY_Y			126
#define PLAYER_H		64
#define PLAYER2_H		64
#define ENEMY_H			61
// Damage
#define DMG_PLAYER		10
#define DMG_ENEMY		10

#define Y 123
int frameM = 0;											// Indice de frame para Mazinger
int frameM2 = 0;
int frameA = 0;											// Indice de frame para Abdora(enemigo)
int frameD = 0;											// Indice de frame para DoublasM2(enemigo)
int frameK = 0;											// Indice de frame para Kingdan(enemigo)

// Posiciones definidas (x)
int M = 120;											// Mazinger
int A = 0;												// Abdora
int D = 282;											// Doublas M2
int K = 0;												// Kingdan
int D1 = 0;
int K1 = 282;
int M2 = 185;

// Limites
int maxLimit = 157 - 37; 								// 123

//------ Enemigo ------//
uint8_t enemy_state = 0;	// Estados
uint8_t enemy_state2 = 0;
uint32_t enemy_timer = 0;								// Tiempos de frames
uint32_t enemy_move_delay = 100;	// Velocidad de animacion
uint32_t enemy_timer2 = 0;
uint32_t enemy_attack_delay = 500;						// Tiempo de cada frame de golpe

uint8_t x = 20;

uint8_t ready = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;
DMA_HandleTypeDef hdma_dac2;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
// Fondos
extern uint16_t fight[];								// Escenario de pelea (memoria FLASH)
extern uint16_t start[];								// Escenario de meny de inicio (memoria FLASH)
extern uint16_t title[];

// Switch/Case variables
uint8_t finish = 0;										// Variable para el "while"
uint8_t main_state = 0;									// Variable de cambio principal
uint8_t state = 0;										// Variable de cambio
uint32_t timer_frames = 0;								// Temporizador para controlar el tiempo de frames
uint8_t show_text = 0;									// Control para parpadeo
uint32_t blink_timer = 0;								// Temporizador para blink
uint8_t title_shown = 0;								// Bandera para saber si ya mostramos el titulo
uint8_t finish_animation = 0;							// Bandera que indica que el inicio ya se ejecuto

//------ Control de juego ------//
volatile uint8_t action = 7;				// Accion actual
volatile uint8_t action2 = 7;
uint8_t lastDir = 0;
uint8_t lastDir2 = 0;
uint32_t lastUpdate = 0;
const uint32_t frameDelay = 80;

//------ HP/Colisiones/Damage ------//
int playerHP = 100;
int player2HP = 100;
int enemyHP = 100;
int enemy2HP  = 100;
const int maxHP = 100;
uint8_t enemy_damage = 1;
uint8_t enemy2_damage  = 1;  // Permite que J2 vuelva a dañar a E2
uint8_t player_damage = 1;
uint8_t player2_damage = 1;

//------ UART ------//
uint8_t buffer[1];
uint8_t buffer2[1];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_DAC_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */
//------ Players ------//
void updatePlayer(void);
void updatePlayer2(void);
void updateEnemyD(void);
void updateEnemyK(void);

//------ Collisions ------//
uint8_t rectsOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh);
uint8_t checkCollision(int attackerX, int attackerW, int attackerY, int attackerH,
		int targetX, int targetW, int targetY, int targetH);
void drawHealthBars(void);
void drawBarWithBorder(int x, int y, int w, int h, int hp);

//------ DAC/Music variables ------//
#define size 128
uint16_t Ysine[size];
#define PI 3.1416
#define TIM_FREQ 84000000
#define PSC 1
int melody[] = {NOTE_G4, NOTE_G4, NOTE_G4, NOTE_G4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_B4, 	// “Ma-zin-ger”
	    NOTE_C5, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_F4, NOTE_G4, NOTE_E4,                   				// “Zeee!”
	    NOTE_G4, NOTE_C5, NOTE_G4, NOTE_C5, NOTE_G5, NOTE_F5, NOTE_E5, NOTE_D5, NOTE_C5};  				// cierre heroico
int durations[] = {180, 180, 180, 180, 150, 150, 180, 180, 300,
	    200, 180, 180, 180, 150, 150, 400,
	    180, 180, 180, 180, 250, 180, 180, 180, 600};
int pauses[] = {
    200, 200, 200, 200, 180, 180, 200, 200, 400,
    250, 220, 220, 220, 180, 180, 450,
    220, 220, 220, 220, 250, 220, 220, 220, 700
};


void M_movement_leftright();										// Movimiento manual a la derecha (Mazinger)
void M_movement_rightleft();											// Movimiento manual a la izquierda (Mazinger)

void A_movement_leftright();
void A_movement_rightleft();
void D_movement_leftright();
void D_movement_rightleft();


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//------ Music ------//
void generarSin(void)
{
    for (int x = 0; x < size; x++)
    {
        Ysine[x] = (uint16_t)((sin(x * 2 * PI / size) + 1) * 2047);
    }
}

int calcularARR(int freq)
{
	if(freq == 0) return 0;
	int TF = size * freq;
	return ((TIM_FREQ/((PSC + 1) * TF)) - 1);
}

void playTone(int *tone, int *duration, int *pause, int Nsize)
{
    for (int i = 0; i < Nsize; i++)
    {
        int freq = tone[i];
        int dur = duration[i];
        int pauseBetweenTones = 0;
        if (pause != NULL)
            pauseBetweenTones = pause[i] - dur;

        if (freq > 0)
        {
            int valorARR = calcularARR(freq);
            HAL_TIM_Base_Stop(&htim6);
            __HAL_TIM_SET_COUNTER(&htim6, 0);
            __HAL_TIM_SET_AUTORELOAD(&htim6, valorARR);
            HAL_TIM_Base_Start(&htim6);
        }
        else
        {
            HAL_TIM_Base_Stop(&htim6);
        }

        HAL_Delay(dur);
        HAL_TIM_Base_Stop(&htim6); // silencia al terminar la nota
        HAL_Delay(pauseBetweenTones);
    }
}

void noTone(void)
{
	TIM6->ARR = 0;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_DAC_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */

  generarSin();
  HAL_DAC_Init(&hdac);
  HAL_TIM_Base_Start(&htim6);
  HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_2, Ysine, size, DAC_ALIGN_12B_R);

  HAL_UART_Receive_IT(&huart4, buffer, 1);
  HAL_UART_Receive_IT(&huart5, buffer2, 1);

// Pantalla
  LCD_Init();
  LCD_Clear(0x00);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  playTone(melody, durations, pauses, sizeof(melody)/sizeof(int));

  while (1)
  {

	switch(main_state){

	case 0:
	{

		switch(state){

		case 0:
			if(finish_animation == 0){
				LCD_Bitmap(0 , 0, 320, 240, fight);							// Cargamos escenario
				LCD_Bitmap(110, 144, 33, 43, mazinger1_down_left);			// Mostramos ambos personajes
				LCD_Bitmap(177, 144, 33, 43, mazinger2_down_left);			// agachados

				finish_animation = 1;
				timer_frames = HAL_GetTick();
			}
			if(HAL_GetTick() - timer_frames >= 1000){
				state = 1;
				finish_animation = 0;											// Reiniciamos bandera
				timer_frames = HAL_GetTick();									// Reiniciamos timer
			}
				break;

		case 1:
			if(finish_animation == 0){
				timer_frames = HAL_GetTick();
				finish_animation = 1;
			}
			if(K < 80){
				V_line(K-1, 123, 63, 0x1cff);
				LCD_Sprite(K, 123, 47, 63, movKingdan, 4, frameK, 0, 0);
				K += 1;
				frameK = ((HAL_GetTick()/500) % 4);
			}
			if(D > 200){
				V_line(D+37, 126, 60, 0x1cff);
				LCD_Sprite(D, 126, 37, 61, movDoublasM2, 4, frameD, 1, 0);
				D -= 1;
				frameD = ((HAL_GetTick()/200) % 4);
			}
			if(K >= 20 && D <= 255){
				state = 2;
				finish_animation = 0;
				timer_frames = HAL_GetTick();
			}
				break;

		case 2:
			if(finish_animation == 0){
				timer_frames = HAL_GetTick();
				finish_animation = 1;
			}
			// Duracion de la animacion 600ms
			if(HAL_GetTick() - timer_frames < 300){
				// Primer frame
				LCD_Sprite(K, 115, 72, 72, hit1_kingdan, 3, 0, 0, 0);			// frame 0
				FillRect(256, 127, 25, 6, 0x1cff);							// Limpiar
				LCD_Sprite(218, 133, 75, 54, hit1_doublas, 3, 0, 1, 0); 		// frame 0
			}
			else if(HAL_GetTick() - timer_frames < 600){
				// Segundo frame
				LCD_Sprite(K, 115, 72, 72, hit1_kingdan, 3, 1, 0 , 0); 		// frame 1
				LCD_Sprite(218, 133, 75, 54, hit1_doublas, 3, 1, 1, 0);		// frame 1
			}
			else if(HAL_GetTick() - timer_frames < 900){
				// Tercer frame
				LCD_Sprite(K, 115, 72, 72, hit1_kingdan, 3, 2, 0, 0);			// frame 2
				LCD_Sprite(218, 133, 75, 54, hit1_doublas, 3, 2, 1, 0);		// frame 2
			}
			else{
				// Final de animacion
				state = 3;
				finish_animation = 0;
				timer_frames = HAL_GetTick();
			}
				break;

		case 3:

			LCD_Bitmap(110, 123, 34, 64, mazinger1_left);
			LCD_Bitmap(177, 123, 34, 64, mazinger2_right);
			FillRect(K+48, 122, 20, 65, 0x1cff);
			FillRect(D-20, 129, 20, 58, 0x1cff);
			LCD_Bitmap(K, 124, 48, 63, kingdan_left);
			LCD_Bitmap(D, 128, 37, 59, doublasm2_right);

			state = 4;
				 break;

		case 4:
			if(finish_animation == 0){
				timer_frames = HAL_GetTick();
				blink_timer = HAL_GetTick();
				finish_animation = 1;
			}
			// Mazingers en defensa
			if(HAL_GetTick() - timer_frames < 500 && title_shown == 0){
				FillRect(109, 124, 25, 5, 0x1cff);
				FillRect(177, 124, 25, 5, 0x1cff);
				LCD_Bitmap(109, 129, 35, 58, mazinger1_defense_left);
				LCD_Bitmap(177, 129, 35, 58, mazinger2_defense_left);
			}
			else if(HAL_GetTick() - timer_frames >= 500 && title_shown == 0){
				// Mostramos el titulo
				LCD_Bitmap(96, 35, 120, 50, title);
				title_shown = 1;
			}
			else if(title_shown == 1){
				if(HAL_GetTick() - blink_timer >= 500){
					show_text = !show_text;
					blink_timer = HAL_GetTick();

					FillRect(33, 99, 255, 12, 0xf800);

					// Si show_text es 1, mostramos texto
					if(show_text){
						LCD_Print("Presiona para activar a Mazinger", 33, 99, 1, 0x0000, 0x14df);
					}
				}
				if(ready){
					main_state = 1;
					finish_animation = 0;
					title_shown = 0;
				}
			}
				 break;
		}
		break;
	}

	case 1:
	{
		LCD_Clear(0x00);
		// Fondo
		LCD_Bitmap(0, 0, 320, 240, fight);

		FillRect(157, 0, 3, 187, 0xffff);										// Division

		// Jugador
		LCD_Bitmap(M, 123, 34, 64, mazinger1_left);
		LCD_Bitmap(M2, 123, 34, 64, mazinger2_right);

		drawHealthBars();

		finish = 1;

		while(finish == 1){
			// Actualizar frameDelay
			uint32_t now = HAL_GetTick();
			if(now - lastUpdate >= frameDelay)
			{
				lastUpdate = now;
				updatePlayer();
				updatePlayer2();
				updateEnemyD();
				updateEnemyK();
			}
		}

		break;
	}

	}


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 1000-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin|LCD_D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LCD_D1_GPIO_Port, LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_D7_Pin|LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART4)
    {
        if (buffer[0] >= '0' && buffer[0] <= '9')
        {
            action = buffer[0] - '0';
        }
        HAL_UART_Receive_IT(&huart4, buffer, 1);
    }
    if (huart->Instance == UART5)
    {
            if (buffer2[0] >= '0' && buffer2[0] <= '9')
            {
                action2 = buffer2[0] - '0';
            }
            HAL_UART_Receive_IT(&huart5, buffer2, 1);
    }
    ready = 1;
}

void updatePlayer(void)
{
  switch(action)
  {
    // HIT (conservamos case 0 como acordado)
    case 0: // Golpe
    	int atkW = 12;
    	int atkX, atkY = PLAYER_Y, atkH = PLAYER_H;

      if(lastDir == 0)
      {
    	atkX = M - atkW;
        LCD_Bitmap(M-12, 124, 46, 63, hit_mazinger1_left);
        FillRect(M-12, 123, 12, 63, 0x1cff);
      }
      if(lastDir == 1)
      {
    	atkX = M + PLAYER_W;
        LCD_Bitmap(M, 124, 46, 63, hit_mazinger1_right);
        FillRect(M+37, 123, 12, 64, 0x1cff);
      }

      int enemyX = D1;
      int enemyY = ENEMY_Y;
      int enemyW = ENEMY_W;
      int enemyH = ENEMY_H;

      if(enemy_damage &&
    		  checkCollision(atkX, atkW, atkY, atkH, enemyX, enemyW, enemyY, enemyH))
      {
    	  enemyHP -= DMG_PLAYER;
    	  if(enemyHP < 0) enemyHP = 0;
    	  enemy_damage = 0;
    	  drawHealthBars();
      }
      break;

    // DEFENSE UP
    case 2:
      if(lastDir == 0)
      {
        FillRect(M-3, 123, 34, 6, 0x1cff);
        LCD_Bitmap(M-3, 129, 35, 58, mazinger1_defense_left);
      }
      if(lastDir == 1)
      {
        FillRect(M, 123, 34, 6, 0x1cff);
        LCD_Bitmap(M, 129, 35, 58, mazinger1_defense_right);
      }
      break;

    // DUCK DOWN
    case 3:
      if(lastDir == 1)
      {
        FillRect(M, 123, 34, 21, 0x1cff);
        LCD_Bitmap(M, 144, 33, 43, mazinger1_down_right);
      }
      if(lastDir == 0)
      {
        FillRect(M, 123, 34, 21, 0x1cff);
        LCD_Bitmap(M, 144, 33, 43, mazinger1_down_left);
      }
      break;

    // MOVE LEFT
    case 4:
      V_line(M+30, Y, 63, 0x1cff);
      LCD_Sprite(M, Y, 30, 64, movM1, 4, frameM, 1, 0);
      M -= 1;
      frameM = (frameM+1) % 4;
      lastDir = 0;
      enemy_damage = 1;
      break;

    // MOVE RIGHT
    case 5:
    if(M < maxLimit){
      V_line(M-1, Y, 63, 0x1cff);
      LCD_Sprite(M, Y, 30, 64, movM1, 4, frameM, 0, 0);
      M += 1;
      frameM = (frameM+1) % 4;
      lastDir = 1;
    }
    enemy_damage = 1;
      break;

    // IDLE (default)
    case 7:
    default:
      FillRect(M-3, 123, 3, 64, 0x1cff);
      FillRect(M+34, 123, 3, 64, 0x1cff);
      if(lastDir == 0) LCD_Bitmap(M, 123, 34, 64, mazinger1_left);
      if(lastDir == 1) LCD_Bitmap(M, 123, 34, 64, mazinger1_right);
      enemy_damage = 1;
      break;
  }
}

void updatePlayer2(void)
{
	switch(action2)
	{
	// Punch
	case 0:
    	int atkW2 = 12;
    	int atkX2, atkY2 = PLAYER2_Y, atkH2 = PLAYER2_H;
		if(lastDir2 == 0)
		{
			atkX2 = M2 - atkW2;
			LCD_Bitmap(M2-12, 124, 46, 63, hit_mazinger2_left);
			FillRect(M2-12, 123, 12, 63, 0x1cff);
		}
		if(lastDir2 == 1)
		{
			atkX2 = M2 + PLAYER2_W;
        	FillRect(M2+37, 123, 12, 64, 0x1cff);
        	LCD_Bitmap(M2, 124, 46, 63, hit_mazinger2_right);
		}

	    int enemy2X = K1;
	    int enemy2Y = ENEMY_Y;
	    int enemy2W = ENEMY_W;
	    int enemy2H = ENEMY_H;

	    if(enemy2_damage &&
	        checkCollision(atkX2, atkW2, atkY2, atkH2, enemy2X, enemy2W, enemy2Y, enemy2H))
	    {
	        enemy2HP -= DMG_PLAYER;
	        if(enemy2HP < 0) enemy2HP = 0;
	        enemy2_damage = 0;
	        drawHealthBars();
	    }
	    break;

	// Guard up
	case 2:
        if(lastDir2 == 0)
        {
            FillRect(M2-3, 123, 34, 6, 0x1cff);
            LCD_Bitmap(M2-3, 129, 35, 58, mazinger2_defense_right);
        }
        if(lastDir2 == 1)
        {
            FillRect(M2, 123, 34, 6, 0x1cff);
            LCD_Bitmap(M2, 129, 35, 58, mazinger2_defense_left);
        }
        break;
    // Duck DOWN
	case 3:
        if(lastDir2 == 1)
        {
            FillRect(M2, 123, 34, 21, 0x1cff);
            LCD_Bitmap(M2, 144, 33, 43, mazinger2_down_left);
        }
        if(lastDir2 == 0)
        {
            FillRect(M2, 123, 34, 21, 0x1cff);
            LCD_Bitmap(M2, 144, 33, 43, mazinger2_down_right);
        }
        break;
    // LEFT
	case 4:
		if(M2 > 164)
		{
	        V_line(M2+30, Y, 63, 0x1cff);
	        LCD_Sprite(M2, Y, 30, 64, movM2, 4, frameM2, 1, 0);
	        M2 -= 1;
	        frameM2 = (frameM2+1) % 4;
	        lastDir2 = 0;
	        enemy_damage = 1;
		}
        break;
    // RIGHT
	case 5:
        V_line(M2-1, Y, 63, 0x1cff);
        LCD_Sprite(M2, Y, 30, 64, movM2, 4, frameM2, 0, 0);
        M2 += 1;
        frameM2 = (frameM2+1) % 4;
        lastDir2 = 1;
        enemy_damage = 1;
        break;
    // Default
	case 7:
		FillRect(M2-3, 123, 3, 64, 0x1cff);
		FillRect(M2+34, 123, 3, 64, 0x1cff);
        if(lastDir2 == 0) LCD_Bitmap(M2, 123, 34, 64, mazinger2_left);
        if(lastDir2 == 1) LCD_Bitmap(M2, 123, 34, 64, mazinger2_right);
        enemy_damage = 1;
    	break;
	}
}



void updateEnemyD(void)
{
	uint32_t now = HAL_GetTick();

	switch(enemy_state){
		case 0:								// Entrada
			if(now - enemy_timer >= enemy_move_delay){
				enemy_timer = now;

				V_line(D1-1, 125, 61, 0x1cff);
				LCD_Sprite(D1, 126, 37, 61, movDoublasM2, 4, frameD, 0, 0);
				D1 += 1;
				frameD = (frameD + 1) % 4;

				if(D1 > 20){
					enemy_state = 1;
					frameD = 0;
				}
			}
			break;

		case 1:
			if(now - enemy_timer < enemy_attack_delay)
			{
				FillRect(20, 127, 38, 6, 0x1cff);
				LCD_Sprite(20, 133, 75, 54, hit1_doublas, 3, 0, 0, 0);
			}
			else if(now - enemy_timer < 2 * enemy_attack_delay)
			{
				LCD_Sprite(20, 133, 75, 54, hit1_doublas, 3, 1, 0, 0);
			}
			else if(now - enemy_timer < 3 * enemy_attack_delay)
			{
				LCD_Sprite(20, 133, 75, 54, hit1_doublas, 3, 2, 0, 0);
			}
			else
			{
				enemy_state = 2;
				frameD = 0;
				D1 = 20;
				player_damage = 1;
				break;
			}
			if((now - enemy_timer) >= enemy_attack_delay && (now - enemy_timer) < 2*enemy_attack_delay)
			{
				int eAtkX = D1 + ENEMY_W;
		        int eAtkW = 30;            // alcance aprox del puño
		        int eAtkY = ENEMY_Y;
		        int eAtkH = ENEMY_H;

		        int pX = M, pY = PLAYER_Y, pW = PLAYER_W, pH = PLAYER_H;

		        if(player_damage &&
		                   checkCollision(eAtkX, eAtkW, eAtkY, eAtkH, pX, pW, pY, pH))
		        {
		        	playerHP -= DMG_ENEMY;
		            if(playerHP < 0) playerHP = 0;
		            player_damage = 0; // no repetir daño durante la misma animación
		            drawHealthBars();
		        }
			}
			break;

		case 2:
			if(now - enemy_timer >= enemy_move_delay){
				enemy_timer = now;

				V_line(D1+37, 125, 61, 0x1cff);
				FillRect(D1+37, 125, 34, 61, 0x1cff);
				LCD_Sprite(D1, 126, 37, 61, movDoublasM2, 4, frameD, 0, 0);
				D1 -= 1;
				frameD = (frameD + 1) % 4;

				if(D1 <= 0){
					enemy_state = 0;
					frameD = 0;
				}
			}
			break;
	}
}

void updateEnemyK(void)
{
    uint32_t now = HAL_GetTick();

    switch(enemy_state2){
        case 0: // Entrada desde la derecha (K1 parte en 282)
            if(now - enemy_timer >= enemy_move_delay){
                enemy_timer = now;

				V_line(K1+37, 125, 61, 0x1cff);
                LCD_Sprite(K1, 126, 37, 61, movDoublasM2, 4, frameD, 1, 0);
                K1 -= 1;   // Avanza hacia el centro
                frameD = (frameD + 1) % 4;

                if(K1 <= 250){ // Límite de entrada (ajústalo si quieres que llegue más)
                    enemy_state2 = 1;
                    frameD = 0;
                    player2_damage = 1;
                    enemy_timer = now;
                }
            }
            break;

        case 1: // Ataque
            if(now - enemy_timer < enemy_attack_delay)
            {
				FillRect(K1, 127, 38, 6, 0x1cff);
                LCD_Sprite(K1 - 40, 133, 75, 54, hit1_doublas, 3, 0, 1, 0);
            }
            else if(now - enemy_timer < 2 * enemy_attack_delay)
            {
                LCD_Sprite(K1 - 40, 133, 75, 54, hit1_doublas, 3, 1, 1, 0);
            }
            else if(now - enemy_timer < 3 * enemy_attack_delay)
            {
                LCD_Sprite(K1 - 40, 133, 75, 54, hit1_doublas, 3, 2, 1, 0);
            }
            else
            {
                enemy_state2 = 2;
                frameD = 0;
                enemy_timer = now;
            }

            // Colisión durante segundo frame del golpe
            if((now - enemy_timer) >= enemy_attack_delay && (now - enemy_timer) < 2 * enemy_attack_delay)
            {
                int eAtkX = K1 - 30;  // Golpea hacia la izquierda
                int eAtkW = 30;
                int eAtkY = ENEMY_Y;
                int eAtkH = ENEMY_H;

                if(player2_damage && checkCollision(eAtkX, eAtkW, eAtkY, eAtkH, M2, PLAYER2_W, PLAYER2_Y, PLAYER2_H))
                {
                    player2HP -= DMG_ENEMY;
                    if(player2HP < 0) player2HP = 0;
                    player2_damage = 0;
                    drawHealthBars();
                }
            }
            break;

        case 2: // Salida hacia la derecha
            if(now - enemy_timer >= enemy_move_delay){
                enemy_timer = now;

                V_line(K1-1, 126, 61, 0x1cff);
                LCD_Sprite(K1, 126, 37, 61, movDoublasM2, 4, frameD, 1, 0);
                K1 += 1;
                frameD = (frameD + 1) % 4;

                if(K1 >= 282){ // Reinicia ciclo
                    enemy_state2 = 0;
                    frameD = 0;
                }
            }
            break;
    }
}


uint8_t rectsOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh)
{
	  if(ax + aw <= bx) return 0;
	  if(bx + bw <= ax) return 0;
	  if(ay + ah <= by) return 0;
	  if(by + bh <= ay) return 0;
	  return 1;
}

uint8_t checkCollision(int attackerX, int attackerW, int attackerY, int attackerH,
        int targetX,   int targetW,   int targetY,   int targetH)
{
	  return rectsOverlap(attackerX, attackerY, attackerW, attackerH,
	                      targetX,   targetY,   targetW,   targetH);
}

void drawBarWithBorder(int x, int y, int w, int h, int hp)
{
	  if(hp < 0) hp = 0;
	  if(hp > maxHP) hp = maxHP;

	  // Borde blanco
	  FillRect(x-1,     y-1,     w+2, 1, 0xffff);
	  FillRect(x-1,     y+h,     w+2, 1, 0xffff);
	  FillRect(x-1,     y-1,     1,   h+2, 0xffff);
	  FillRect(x+w,     y-1,     1,   h+2, 0xffff);

	  // Fondo gris
	  FillRect(x, y, w, h, 0x8410);

	  // Porción de vida en verde
	  int fill = (w * hp) / maxHP;
	  if(fill > 0) FillRect(x, y, fill, h, 0x07E0);
}

void drawHealthBars(void)
{
    const int w = 120;
    const int h = 8;

    // TOP
    int yTop = 10;
    int xLeftTop  = 10;                 // Player1
    int xRightTop = 320 - 10 - w;       // Enemy1

    // BOTTOM
    int yBottom = 240 - 10 - h;         // 240 alto pantalla
    int xLeftBottom  = 10;              // Player2
    int xRightBottom = 320 - 10 - w;    // Enemy2

    // Limpiar fondo de barras (opcional, rápido)
    // (Se puede comentar si no parpadea)
    // FillRect(0, 0, 320, 40, 0x0000);
    // FillRect(0, 240-40, 320, 40, 0x0000);

    // Player1 (arriba izquierda)
    drawBarWithBorder(xLeftTop, yTop, w, h, playerHP);

    // Enemy1  (arriba derecha)
    drawBarWithBorder(xRightTop, yTop, w, h, enemyHP);

    // Player2 (abajo izquierda)
    drawBarWithBorder(xLeftBottom, yBottom, w, h, player2HP);

    // Enemy2  (abajo derecha)
    drawBarWithBorder(xRightBottom, yBottom, w, h, enemy2HP);
}

void M_movement_rightleft()												// Movimiento para izquierda
{
	FillRect(M+30, 123, 2, 63, 0x1cff);
	LCD_Sprite(M, 123, 30, 64, movM1, 4, frameM, 1, 0);
	M -= 1;
	frameM = (frameM+1) % 4;
}
void M_movement_leftright()												// Movimiento para derecha
{
	V_line(M-1, 123, 63, 0x1cff);
	LCD_Sprite(M, 123, 30, 64, movM1, 4, frameM, 0, 0);
	M += 1;
	frameM = (frameM+1) % 4;
}

void D_movement_rightleft()				// NOT USED
{
	for(int i = 0; i < 35; i++)
	{
		V_line(D+37, 131, 60, 0x1cff);
		LCD_Sprite(D, 131, 37, 61, movDoublasM2, 4, frameD, 1, 0);
		D -= 1;
		frameD = (i/5) % 4;
	}
}
void D_movement_leftright()				// NOT USED
{
	for(int i = 0; i < 35; i++)
	{
		V_line(D-1, 126, 60, 0x1cff);
		LCD_Sprite(D, 126, 37, 61, movDoublasM2, 4, frameD, 0, 0);
		D += 1;
		frameD = (i/5) % 4;
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
